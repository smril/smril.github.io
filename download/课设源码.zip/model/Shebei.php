<?php
namespace app\keshe\model;
use think\Model;
use think\model\SoftDelete;
class Shebei extends Model 
{
    //protected $pk = 'uid';
}
<?php
namespace app\keshe\model;
use think\Model;
use think\model\SoftDelete;
class Weixiu extends Model 
{
    //protected $pk = 'uid';
}
<?php
namespace app\keshe\model;
use think\Model;
class Login extends Model 
{
    //protected $pk = 'uid';
}
<?php
namespace app\keshe\model;
use think\Model;
use think\model\SoftDelete;
class Guzhang extends Model 
{
    //protected $pk = 'uid';
}
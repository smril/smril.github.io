<?php
namespace app\keshe\model;
use think\Model;
use think\model\SoftDelete;
class Yonghu extends Model 
{
    //protected $pk = 'uid';
}
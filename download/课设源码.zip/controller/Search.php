<?php
namespace app\keshe\controller;
#use think\Controller;
use app\keshe\controller\Base;
use app\keshe\model\Shebei as UserModel;
use app\keshe\validate\Val as UserValidate;
class Search extends Base
{
    public function list()
    {
        //$data = UserModel::all();
        //$this->assign('data',$data);
        //return $this->fetch();
        $data = UserModel::paginate(8);
        $page = $data->render();
        $this->assign('data',$data);
        $this->assign('page',$page);
        return $this->fetch();
    }
    public function listp()
    {
        $data = UserModel::paginate(8);
        $page = $data->render();
        $this->assign('data',$data);
        $this->assign('page',$page);
        return $this->fetch();
    }
    public function edit()
    {
        $shebeihao = input('get.shebeihao');
        $data = UserModel::get($shebeihao);
        $this->assign('data',$data);
        return $this->fetch();
    }
    public function update()
    {
        $data = input('post.');
        $shebeihao = input('post.shebeihao');
        $val = new UserValidate();
        if (!$val->check($data)){
            $this->error($val->getError());
            exit;
        }
        $user = new UserModel();
        $ret = $user->allowField(true)->save($data,['shebeihao'=>$shebeihao]);
        if($ret){
            $this->success('修改设备信息成功','Search/list');
        }
        else{
            $this->error('修改设备信息失败');
        }
    }
    public function delete()
    {
        $shebeihao = input('get.shebeihao');
        $ret = UserModel::destroy($shebeihao);
        if($ret){
            $this->success('删除设备成功','Search/list');
        }
        else{
            $this->error('删除设备失败');
        }
    }
}
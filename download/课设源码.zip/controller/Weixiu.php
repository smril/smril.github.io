<?php
namespace app\keshe\controller;
#use think\Controller;
use app\keshe\controller\Basew;
use app\keshe\model\Weixiu as UserModel;
use app\keshe\validate\Valwei as UserValidate;
class Weixiu extends Basew
{
    public function Weixiu()
    {
       return $this->fetch();
    }
    public function insert()
    {
        $data = input('post.');
        $valgu = new UserValidate();
        if (!$valgu->check($data)){
            $this->error($valgu->getError());
            exit;
        }
        $user = new UserModel($data);
        $ret = $user->allowField(true)->save();
        if($ret){
            $this-> success('插入成功','weixiu');
        }
        else{
            $this->error('插入失败');
        }
    }
    public function list()
    {
        $data = UserModel::paginate(8);
        $page = $data->render();
        $this->assign('data',$data);
        $this->assign('page',$page);
        return $this->fetch();
    }
    public function edit()
    {
        $weixiuhao = input('get.weixiuhao');
        $data = UserModel::get($weixiuhao);
        $this->assign('data',$data);
        return $this->fetch();
    }
    public function update()
    {
        $data1 = input('post.');
        $weixiuhao = input('post.weixiuhao');
        $valgu = new UserValidate();
        if (!$valgu->check($data1)){
            $this->error($valgu->getError());
            exit;
        }
        $user = new UserModel();
        $ret1 = $user->allowField(true)->save($data1,['weixiuhao'=>$weixiuhao]);
        if($ret1){
            $this->success('修改故障信息成功','Weixiu/list');
        }
        else{
            $this->error('修改故障信息失败');
        }
    }
    public function delete()
    {
        $weixiuhao = input('get.weixiuhao');
        $ret = UserModel::destroy($weixiuhao);
        if($ret){
            $this->success('删除设备成功','Weixiu/list');
        }
        else{
            $this->error('删除设备失败');
        }
    }
    public function guzhang()
    {
        $this->success('','guzhang/list');
    }
}
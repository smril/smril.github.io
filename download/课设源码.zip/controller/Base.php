<?php
namespace app\keshe\controller;
use think\Controller;
class Base extends Controller
{
    public function _initialize()
    {
        if(!session('yonghuleibie')){
            $this->error('请先登录系统！','Login/login');
        }
        else{
            if(session('yonghuleibie') != 3)
            {
                if(session('yonghuleibie') != 4)
                {
                $this->error('您的权限无法访问此表！');}
            }
        }
    }
}
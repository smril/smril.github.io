<?php
namespace app\keshe\controller;
#use think\Controller;
use app\keshe\controller\Basew;
use app\keshe\model\Guzhang as UserModel;
use app\keshe\validate\Valgu as UserValidate;
class Guzhang extends Basew
{
    public function Guzhang()
    {
       return $this->fetch();
    }
    public function insert1()
    {
        $data = input('post.');
        $valgu = new UserValidate();
        if (!$valgu->check($data)){
            $this->error($valgu->getError());
            exit;
        }
        $user = new UserModel($data);
        $ret = $user->allowField(true)->save();
        if($ret){
            $this-> success('插入成功','Guzhang');
        }
        else{
            $this->error('插入失败');
        }
    }
    public function list()
    {
        $data = UserModel::paginate(8);
        $page = $data->render();
        $this->assign('data',$data);
        $this->assign('page',$page);
        return $this->fetch();
    }
    public function edit()
    {
        $guzhangxuhao = input('get.guzhangxuhao');
        $data = UserModel::get($guzhangxuhao);
        $this->assign('data',$data);
        return $this->fetch();
    }
    public function update()
    {
        $data1 = input('post.');
        $guzhangxuhao = input('post.guzhangxuhao');
        $valgu = new UserValidate();
        if (!$valgu->check($data1)){
            $this->error($valgu->getError());
            exit;
        }
        $user = new UserModel();
        $ret1 = $user->allowField(true)->save($data1,['guzhangxuhao'=>$guzhangxuhao]);
        if($ret1){
            $this->success('修改故障信息成功','Guzhang/list');
        }
        else{
            $this->error('修改故障信息失败');
        }
    }
    public function delete()
    {
        $shebeihao = input('get.guzhangxuhao');
        $ret = UserModel::destroy($shebeihao);
        if($ret){
            $this->success('删除设备成功','Guzhang/list');
        }
        else{
            $this->error('删除设备失败');
        }
    }
}
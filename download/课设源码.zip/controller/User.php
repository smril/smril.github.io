<?php
namespace app\keshe\controller;
use think\Controller;
use app\keshe\model\Shebei as UserModel;
use app\keshe\validate\Val as UserValidate;
class User extends Controller
{
    public function Shebei()
    {
       return $this->fetch();
    }
    public function insert()
    {
        $data = input('post.');
        $val = new UserValidate();
        if (!$val->check($data)){
            $this->error($val->getError());
            exit;
        }
        $user = new UserModel($data);
        $ret = $user->allowField(true)->save();
        if($ret){
            $this-> success('插入成功','Shebei');
        }
        else{
            $this->error('插入失败');
        }
    }
    public function list()
    {
        return $this->fetch();
    }
     public function addlist()
     {
        $user = new UserModel();
        $list=[
            //['shebeihao'=>6,'shebeimingcheng'=>'激光粒度拉曼光谱仪','jiage'=>150,'peizhi'=>'6','changjiamingcheng'=>'北京化工大学','chuchangriqi'=>20200504,'shiyanshiming'=>'北化实验室'],
            //['shebeihao'=>7,'shebeimingcheng'=>'多晶X-射线衍射仪','jiage'=>135,'peizhi'=>'5','changjiamingcheng'=>'北京化工大学','chuchangriqi'=>20200505,'shiyanshiming'=>'北化实验室'],
            ['shebeihao'=>8,'shebeimingcheng'=>'组合式荧光寿命与稳态荧光光谱仪','jiage'=>120,'peizhi'=>'8','changjiamingcheng'=>'北京化工大学','chuchangriqi'=>20181203,'shiyanshiming'=>'北化实验室'],
            ['shebeihao'=>9,'shebeimingcheng'=>'激光直写仪','jiage'=>120,'peizhi'=>'4','changjiamingcheng'=>'北京化工大学','chuchangriqi'=>20141230,'shiyanshiming'=>'北化实验室'],
            ['shebeihao'=>10,'shebeimingcheng'=>'扫描电子显微镜','jiage'=>105,'peizhi'=>'6','changjiamingcheng'=>'北京化工大学','chuchangriqi'=>20100404,'shiyanshiming'=>'北化实验室'],
            ['shebeihao'=>11,'shebeimingcheng'=>'倒置荧光显微镜','jiage'=>70,'peizhi'=>'5','changjiamingcheng'=>'北京化工大学','chuchangriqi'=>20150714,'shiyanshiming'=>'北化实验室'],
            ['shebeihao'=>12,'shebeimingcheng'=>'红外-热失重联用仪','jiage'=>65,'peizhi'=>'6','changjiamingcheng'=>'北京化工大学','chuchangriqi'=>20160916,'shiyanshiming'=>'北化实验室'],
            ['shebeihao'=>13,'shebeimingcheng'=>'太阳光模拟器','jiage'=>65,'peizhi'=>'5','changjiamingcheng'=>'北京化工大学','chuchangriqi'=>19990705,'shiyanshiming'=>'北化实验室'],
            ['shebeihao'=>14,'shebeimingcheng'=>'分析型高效液相色谱仪','jiage'=>55,'peizhi'=>'4','changjiamingcheng'=>'北京化工大学','chuchangriqi'=>20200503,'shiyanshiming'=>'北化实验室'],
        ];
        if($user->saveall($list)){
            return '用户新增成功批量';
        }
        else{
            return '用户新增失败';
        }
     }

}
<?php
namespace app\keshe\controller;
#use app\keshe\controller\Base;
use think\Controller;
use app\keshe\model\Login as UserModel;
use app\keshe\validate\Valyong as UserValidate;
class Login extends Controller
{
    public function login()
    {
       
        return $this->fetch();
        
    }
    public function shebei()
    {
        $this->success('','search/list');
    }
    public function weixiu()
    {
        $this->success('','weixiu/list');
    }
    public function guzhang()
    {
        $this->success('','guzhang/list');
    }
    public function check()
    {
        $data = input('post.');
        $user = new UserModel();
        $result = $user->where('yonghuhao',$data['yonghuhao'])->find();
        if($result){
            if($result['mima'] === $data['mima']){
                session('yonghuleibie',$result['yonghuleibie']);
            }
            else{
                $this->error('密码不正确');
            }
        }
        else{
            $this->error('用户名不存在');
            exit;
        }
        if(captcha_check($data['code']))
        {
            if($result['yonghuleibie'] === 4)
                {$this->success('登录成功！','login/index');}
            if($result['yonghuleibie'] === 1)
                {$this->success('登录成功！','login/list');}
            if($result['yonghuleibie'] === 2)
                {$this->success('登录成功！','weixiu/list');} 
            if($result['yonghuleibie'] === 3)
                {$this->success('登录成功！','search/listp');}
            else
            {
                $this->error('用户类别有误！');
            }
        }
        else{
            $this->error('验证码不正确');
        }
    }
    public function index()
    {
        return $this->fetch();
    }
    public function insert()
    {
        $data = input('post.');
        $val = new UserValidate();
        if (!$val->check($data)){
            $this->error($val->getError());
            exit;
        }
        $user = new UserModel($data);
        $ret = $user->allowField(true)->save();
        if($ret){
            $this-> success('新增用户信息成功','Login');
        }
        else{
            $this->error('新增用户信息失败');
        }
    }
    public function list()
    {
        $data = UserModel::paginate(8);
        $page = $data->render();
        $this->assign('data',$data);
        $this->assign('page',$page);
        return $this->fetch();
    }


    public function edit()
    {
        $yonghuhao = input('get.yonghuhao');
        $data = UserModel::get($yonghuhao);
        $this->assign('data',$data);
        return $this->fetch();
    }
    public function update()
    {
        $data1 = input('post.');
        $yonghuhao = input('post.yonghuhao');
        $valyong = new UserValidate();
        if (!$valyong->check($data1)){
            $this->error($valyong->getError());
            exit;
        }
        $user = new UserModel();
        $ret = $user->allowField(true)->save($data1,['yonghuhao'=>$yonghuhao]);
        if($ret){
            $this->success('修改用户信息成功','Login/list');
        }
        else{
            $this->error('修改用户信息失败');
        }
    }
    public function delete()
    {
        $yonghuhao = input('get.yonghuhao');
        $ret = UserModel::destroy($yonghuhao);
        if($ret){
            $this->success('删除用户成功','Login/list');
        }
        else{
            $this->error('删除用户失败');
        }
    }
    public function yonghu()
    {
        return $this->fetch();
    }
    public function addy()
    {
        $this->success('','Login/yonghu');
    }
    public function adds()
    {
        $this->success('','User/shebei');
    }
    public function addg()
    {
        $this->success('','Guzhang/guzhang');
    }
    public function addw()
    {
        $this->success('','Weixiu/weixiu');
    }
}
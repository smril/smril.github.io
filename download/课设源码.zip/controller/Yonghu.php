<?php
namespace app\keshe\controller;
use app\keshe\controller\Base;
use think\Controller;
use app\keshe\model\Yonghu as UserModel;
use app\keshe\validate\Valyong as UserValidate;
class Yonghu extends Base
{
    public function Yonghu()
    {
       return $this->fetch();
    }
    public function insert()
    {
        $data = input('post.');
        $val = new UserValidate();
        if (!$val->check($data)){
            $this->error($val->getError());
            exit;
        }
        $user = new UserModel($data);
        $ret = $user->allowField(true)->save();
        if($ret){
            $this-> success('新增用户信息成功','Yonghu');
        }
        else{
            $this->error('新增用户信息失败');
        }
    }
    public function list()
    {
        $data = UserModel::paginate(3);
        $page = $data->render();
        $this->assign('data',$data);
        $this->assign('page',$page);
        return $this->fetch();
    }


    public function edit()
    {
        $yonghuhao = input('get.yonghuhao');
        $data = UserModel::get($yonghuhao);
        $this->assign('data',$data);
        return $this->fetch();
    }
    public function update()
    {
        $data1 = input('post.');
        $yonghuhao = input('post.yonghuhao');
        $valyong = new UserValidate();
        if (!$valyong->check($data1)){
            $this->error($valyong->getError());
            exit;
        }
        $user = new UserModel();
        $ret = $user->allowField(true)->save($data1,['yonghuhao'=>$yonghuhao]);
        if($ret){
            $this->success('修改用户信息成功','Yonghu/list');
        }
        else{
            $this->error('修改用户信息失败');
        }
    }
    public function delete()
    {
        $yonghuhao = input('get.yonghuhao');
        $ret = UserModel::destroy($yonghuhao);
        if($ret){
            $this->success('删除用户成功','Yonghu/list');
        }
        else{
            $this->error('删除用户失败');
        }
    }
    public function index()
    {
        return $this->fetch();
    }
}
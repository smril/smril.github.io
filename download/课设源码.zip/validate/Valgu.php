<?php
namespace app\keshe\validate;
use think\Validate;

class Valgu extends Validate
{
    protected $rule = [
        'guzhangxuhao|故障序号'=>'require',
        'guzhangmingcheng|故障名称'=>'require',
        'shebeihao|设备号'=>'require',
        'guzhangriqi|故障日期'=>'require',
        'guzhangxinxi|故障信息'=>'require',
        'jingshouren|经手人'=>'require',
    ];
    protected $message = [
        'guzhangxuhao.require'=>'故障序号不能为空！',
        'guzhangmingcheng.require'=>'故障名称不能为空！',
        'shebeihao.require'=>'设备号不能为空！',
        'guzhangriqi.require'=>'故障日期不能为空！',
        'guzhangxinxi.require'=>'故障信息不能为空！',
        'jingshouren.require'=>'经手人不能为空！',
    ];
}
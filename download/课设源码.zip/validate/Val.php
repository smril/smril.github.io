<?php
namespace app\keshe\validate;
use think\Validate;

class Val extends Validate
{
    protected $rule = [
        'shebeihao|设备号'=>'require',
        'shebeimingcheng|投影仪'=>'require',
        'jiage|价格'=>'require',
        'peizhi|配置'=>'require',
        'changjiamingcheng|厂家名称'=>'require',
        'chuchangriqi|出厂日期'=>'require',
        'shiyanshiming|实验室名'=>'require',
    ];
    protected $message = [
        'shebeihao.require'=>'设备号不能为空！',
        'shebeimingcheng.require'=>'设备名称不能为空！',
        'jiage.require'=>'价格不能为空！',
        'peizhi.require'=>'配置不能为空！',
        'changjiamingcheng.require'=>'厂家名称不能为空！',
        'chuchangriqi.require'=>'出厂日期不能为空！',
        'shiyanshiming.require'=>'实验室名不能为空！',
    ];
}
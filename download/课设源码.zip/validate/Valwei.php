<?php
namespace app\keshe\validate;
use think\Validate;

class Valwei extends Validate
{
    protected $rule = [
        'weixiuhao|维修号'=>'require',
        'shebeihao|设备号'=>'require',
        'guzhangxuhao|故障序号'=>'require',
        'weixiuriqi|维修日期'=>'require',
        'weixiuneirong|维修内容'=>'require',
        'gaibianpeizhi|改变配置'=>'require',
        'weixiujine|维修金额'=>'require',
        'weixiuren|维修人'=>'require',
    ];
    protected $message = [
        'weixiuhao.require'=>'维修号不能为空！',
        'shebeihao.require'=>'设备号不能为空！',
        'guzhangxuhao.require'=>'故障序号不能为空！',
        'guzhangxinxi维修日期.require'=>'维修日期不能为空！',
        'weixiuneirong.require'=>'维修内容不能为空！',
        'gaibianpeizhi.require'=>'改变配置不能为空！',
        'weixiujine.require'=>'维修金额不能为空！',
        'weixiuren.require'=>'维修人不能为空！',
    ];
}
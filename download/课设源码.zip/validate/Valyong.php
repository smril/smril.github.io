<?php
namespace app\keshe\validate;
use think\Validate;

class Valyong extends Validate
{
	protected $rule = [
        'yonghuhao|用户号'=>'require',
		'yonghuming|用户名'=>'require|min:3',
		'mima|密码'=>'require|min:6|confirm:chongfumima',
		'yonghuleibie|用户类别'=>'require',
	];

	protected $message = [
		'yonghuhao.require'=>'用户名不能为空',
		'yonghuming.min'=>'用户名长度不能少于3位',
		'mima.require'=>'密码不能为空',
		'mima.min'=>'密码长度不能少于6位',
		'mima.confirm'=>'两次密码不一致',
		'yonghuleibie.require'=>'用户类别不能为空',
	];
}
